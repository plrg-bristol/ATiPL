import Sheet1Lean

def main : IO Unit :=
  IO.println s!"Hello, {hello}!"
