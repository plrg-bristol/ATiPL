import Lake
open Lake DSL

package "Sheet1Lean" where
  -- add package configuration options here

lean_lib «Sheet1Lean» where
  -- add library configuration options here

@[default_target]
lean_exe "sheet1lean" where
  root := `Main
