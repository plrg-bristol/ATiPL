-- Code credit: Jess Foster
-- Edited/more comments added by Sam Frohlich

-- S forword:

-- If you are interested in lean, see https://lean-lang.org/lean4/doc/
-- If you would prefer to look into Rocq (renamed from Coq for obvious reasons),
-- then this is a good resourse: https://softwarefoundations.cis.upenn.edu/

-- Styles of using theorem provers:
-- In my opinion Roqc and agda(another theorem prover) are at opposite ends of a
-- specturm that you can place theorem provers on. On the one hand, Roqc is at
-- a very high level of abstratcion, where you use tactics to direct the program
-- to do a logical proof for you. On the other hand, you have Agda which takes advantage
-- of the Curry-Howard iso (that programs are proofs) to construct the proofs as
-- functional programs.

-- I must say that I have not done enough lean to know where it lies, but here
-- atleast, Jess is using it on the functional/constructive style, although I do
-- think you can use tactics in lean

-- Lecture notes:
-- -----------------------------------------------

-- Nat:
open Nat
  -- Nat is predefined in the lean4 prelude, and it comes with lots of predefined
  -- and helpful stuff, so good to use that
  -- inductive Nat where
  --   | zero : Nat
  --   | succ : Nat → Nat
  -- end hidden


-- Much closer to what the rules actually say
-- S: I think the point Jess is making here is that the rules can also be viewed
-- as a judgement of the syntax of the inbuild Nat data type, which might work better
-- in Lean
inductive EvNat : Nat -> Prop where
  | Zero : EvNat zero
  | Succ : EvNat n -> EvNat (succ n)
open EvNat

-- claim: If succ(n) is nat, then n is nat
-- S: In lean, its written just like a function :-D
example : EvNat (succ n) -> EvNat n
  -- | Zero => _ -- Can't happen
  | Succ evNat_n => evNat_n

-- Odd even:
-- S: again this is as a judgement on the Nat syntax, which we sort of got from our
-- discussions in class
mutual
  inductive EvEven : Nat -> Prop where
    | EvenZ : EvEven zero
    | Even : EvOdd n -> EvEven (succ n)

  inductive EvOdd : Nat -> Prop where
    | Odd : EvEven n -> EvOdd (succ n)
end
open EvEven
open EvOdd

-- S: for convenience
def natFromOdd {n : Nat} : EvOdd n -> Nat := λ_ => n
def natFromEven {n : Nat} : EvEven n -> Nat := λ_ => n

theorem inductionEvEvenOdd
  -- the two properties we wanna prove for odd and even
  (p : Nat -> Prop) -- Prop on even numbers
  (q : Nat -> Prop) -- Prop on odd numbers
  -- if you provide all the cases needed for induction
  (pZ : p zero)                                            -- EvenZ case
  (oSucc : {n' : Nat} -> EvEven n' -> p n' -> q (succ n')) -- Odd case
  (eSucc : {n' : Nat} -> EvOdd  n' -> q n' -> p (succ n')) -- Even case
  -- we can prove p and q or all properties on even and off numbers
  (n : Nat)                              -- for all nat
  : (EvEven n -> p n) ∧ (EvOdd n -> q n) -- both hold
  -- we can do this as a function that pattern matches, putting the correct case
  -- in at the correct time
  := let pnE : EvEven n -> p n
         | EvenZ     => pZ
         | Even nO =>
           match inductionEvEvenOdd p q pZ oSucc eSucc (natFromOdd nO) with
           | ⟨_, qnO'⟩ => eSucc nO (qnO' nO)

     let qnO : EvOdd n -> q n
             | Odd nE =>
               match inductionEvEvenOdd p q pZ oSucc eSucc (natFromEven nE) with
               | ⟨pnE', _⟩ => oSucc nE (pnE' nE)
     ⟨pnE, qnO⟩


-- Claim 2. If n even then either n = zero or n = succ(x) where x odd.
example : EvEven n -> n = zero ∨ (∃(x : Nat), EvOdd x ∧ n = succ x)
  | EvenZ        => Or.inl rfl
  | @Even x' nO => Or.inr ⟨x', ⟨nO, rfl⟩⟩
  -- | @Even x' nO => Or.inr (Exists.intro x' (And.intro nO rfl))

-- If you click through this proof, by placing your curser at different points,
-- you can see how lean is helping you by telling you what you need to make and
-- what you have at your desposal
example : EvEven n -> n = zero ∨ (∃(x : Nat), EvOdd x ∧ n = succ x)
  := And.left (inductionEvEvenOdd
       (λn' => n' = zero ∨ (∃(x : Nat), EvOdd x ∧ n' = succ x)) -- p
       (λn' => (∃(x : Nat), EvEven x ∧ n' = succ x)) -- q,  “If n odd then n = succ(x) where x even.”
       (Or.inl rfl)                               -- Zero case
       (λ {n'} nE _ih => ⟨n', ⟨nE , rfl⟩⟩)        -- Odd succ case
       (λ {n'} nO _ih => Or.inr ⟨n', ⟨nO , rfl⟩⟩) -- Even succ case
       n)

-- Sheet One:
-- -----------------------------------------------

-- Q1
example : EvOdd (succ (succ (succ zero))) -- judgement / type
  := Odd (Even (Odd EvenZ))               -- evidence / definition

-- Q2
-- i)
inductive EvList : List Nat -> Prop where
  | Nil  : EvList []
  | Cons : EvNat n -> EvList xs -> EvList (n :: xs)
open EvList

-- ii) Induction principle
def toEvNat : (n : Nat) -> EvNat n
  | zero => Zero
  | succ x => Succ (toEvNat x)

theorem inductionList
  -- provide what you wanna prove
  {p : List Nat -> Prop} -- prop we wanna prove
  (xs : List Nat)        -- for all nat lists
  -- provide what you need to prove
  (h_Nil  : p [])                          -- nil case
  (h_Cons : {n' : Nat} -> {xs' : List Nat} -- cons case
         -> EvNat n' -> p xs' -> p (n' :: xs'))
  -- given the above, we can conclude p holds for xs
  : p xs
  := match xs with
     | [] => h_Nil
     | (n' :: xs') => h_Cons (toEvNat n') (inductionList xs' h_Nil h_Cons)

-- iii)

example : EvList [0, 1]
  := Cons Zero (Cons (Succ Zero) Nil)

-- Q3)

inductive EvSum : Nat -> Nat -> Nat -> Prop where
  | Base : EvNat b -> EvSum zero b b
  | Ind  : EvSum a b c -> EvSum (succ a) b (succ c)
open EvSum

-- i)
example : EvSum (succ zero) (succ zero) (succ (succ zero))
  := Ind (Base (Succ Zero))

-- ii)
-- sum :: Nat -> Nat -> Nat
-- sum Zero     b = b
-- sum (Succ a) b = succ (sum a b)

-- iii)
-- Note that now we are switching to using the inbuilt induction
-- Please click through the proof to see how lean helps you complete the proof
example (sum_ev : EvSum a b c) : EvNat a ∧ EvNat b ∧ EvNat c
  := by induction sum_ev with -- triggers a split to cases, see how it specialises goal for you
        | Base b_ev => exact ⟨Zero, b_ev, b_ev⟩
        | Ind _sumabc_ev ih => -- notice how we have the IH here, but its also like defining a function
          let ⟨a'_ev, b_ev, c'_ev⟩ := ih
          exact ⟨Succ a'_ev, b_ev, Succ c'_ev⟩


-- iv) Existence
example (a_ev : EvNat a) (b_ev : EvNat b) : ∃(c : Nat) (c_ev : EvNat c), EvSum a b c
  := by induction a_ev with
        | Zero => exact ⟨b, b_ev, Base b_ev⟩
        | @Succ a' a'_ev ih =>
            exact (Exists.elim ih (λc' ih' =>
                    Exists.elim ih' (λc'_ev suma'bc'_ev =>
                      ⟨succ c', Succ c'_ev, Ind suma'bc'_ev⟩
                    )))

-- v) Uniqueness
theorem sum_unique : EvSum a b c -> EvSum a b c' -> c = c'
  | Base b_ev, Base b_ev' => rfl
  -- | Base b_ev, Ind _ => -- Can't happen
  | Ind sumx', Ind sumy' => congrArg succ (sum_unique sumx' sumy')

-- vi)
-- "Defines function", i.e. for all nats a and b, there exists exactly one (c : Nat)
-- for which the judgement sum(a, b, c) can be proved

-- The following is not what the question actually asked, but interesting nonetheless
theorem left_succ : ∀{x y : Nat}, succ (x + y) = succ x + y := by
  intro x y
  induction y with
  | zero => simp
  | succ y' ih =>
      show succ (succ (x + y')) = succ x + succ y'
      simp [ih]
      rfl

theorem add_comm' : ∀{x y : Nat}, x + y = y + x := by
  intro x y
  induction y with
  | zero => simp []
  | succ y' ih =>
      show succ (x + y') = succ y' + x
      simp [ih, left_succ]

theorem succl : ∀{x y z : Nat}, x + y = z -> succ x + y = succ z := by
  intro x y z x_plus_y_eq_z
  simp [add_comm']
  show succ (y + x) = succ z
  simp [add_comm', x_plus_y_eq_z]

-- Not really what's being asked for in the question I don't think, but interesting anyway
theorem sum_semantics (sum_ev : EvSum a b c) : a + b = c := by
  induction sum_ev with
  | Base _ => simp
  | Ind _ ih => exact (succl ih)
